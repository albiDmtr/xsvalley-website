<?php
/**
 * Title: Search
 * Slug: bsoj/search
 * Inserter: no
 */
?>

<!-- wp:search {"label":"","showLabel":false,"placeholder":"<?php echo esc_html_x( 'Search...', 'This is a placeholder text in a search field', 'bsoj' ); ?>","buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true} /-->
